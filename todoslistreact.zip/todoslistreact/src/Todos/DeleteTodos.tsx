import axios from "axios";
import React,{Component, useEffect, useState} from "react";
import { Button, Container } from "react-bootstrap";
import { useParams } from "react-router-dom";

type RouteParams = {
    id:string
}

interface Todos {
    id: number;
    todoTitle: string;
    todoDescription: string;
    todoCompleted: string;
}

const DeleteTodos: React.FC = () => {
    
    //reading the router param - url
    const { id } = useParams<RouteParams>();
    const [ myTodos,setMyTodos ] = useState<Todos>();

    const fetchData = async () => {
        const response = await axios.get<Todos>("http://localhost:8040/api/todosLists/" + id);
        setMyTodos(response.data);
    }

    useEffect(() => {
        fetchData();
    },[]);

    const deleteData = async() => {
        await axios.delete("http://localhost:8040/api/todosLists/" + id);
        alert("data deleted");
        //nav("/todoslist");
    }


        return(
            <>
                <Container>
                <h1>Department Delete {id}</h1>
                Title : {myTodos?.todoTitle}
                <br></br>
                Description : {myTodos?.todoDescription}
                <br></br>
                Completed : {myTodos?.todoCompleted}
                <br></br>
                <Button onClick={deleteData} variant="danger" type="button" >Confirm Delete</Button>
                </Container>
            </>
        )     
    }

export default DeleteTodos;
import axios from "axios";
import React,{Component,useEffect,useState} from "react";
import { Button, Col, Container, Form, Row } from "react-bootstrap";
import { Link, useParams,useNavigate } from "react-router-dom";

interface Todos {
    id: number;
    todoTitle: string;
    todoDescription: string;
    todoCompleted: string;
}

type RouteParams = {
    id:string;
}

const UpdateTodos : React.FC = () => {

    const {id} = useParams<RouteParams>();
    const[title,setTitle]= useState("");
    const[description,setDescription]= useState("");

    const nav = useNavigate();

    const fetchData = async () => {
        const response = await axios.get<Todos>("http://localhost:8040/api/todosLists/"+id);
        setTitle(response.data[`todoTitle`]);
        setDescription(response.data[`todoDescription`]);
        
    }

    useEffect(() => {
        fetchData();
    },[]);

    const sendData = async () => {
        const newDepartment ={
            "id" : id,
            "todoTitle":title,
            "todoDescription":description,
            "todoCompleted":" "
        };
        await axios.put("http://localhost:8040/api/todosLists/"+id,newDepartment);
        alert("todos Updated");
        nav("/todoslist");
    }
    const goback=()=>{
        nav("/")
    }
    return (
        <>
        
             <Container>
                <Row>
                    {/* <Col md={12}>Update TodosList</Col> */}
                    <Col md={12}>
                    <Form style={{ width: "400px", marginLeft: "200px", marginTop: "50px" }} >
                            <h4>Update New Todoslist</h4>
                            <br></br>
                            <Form.Group className="mb-3" >
                                <Form.Label>Todos Title</Form.Label>
                                <Form.Control type="text"   value={title} onChange={(e) => setTitle(e.target.value)} />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Todos Description</Form.Label>
                                <Form.Control type="text" value={description} onChange={(e) => setDescription(e.target.value)} />
                            </Form.Group>

                            <Button variant="primary" type="submit" onClick={sendData}>
                                Submit
                            </Button>
                            <Button style={{marginLeft:"10px"}} variant="primary" type="submit" onClick={goback}>Back</Button>
                        </Form>

                   
                </Col>
            </Row>
        </Container >
        
        </>
    );
    
}

export default UpdateTodos;
import axios from "axios";
import React,{Component, useEffect, useState} from "react";
import { Button, Container } from "react-bootstrap";
import { useNavigate, useParams } from "react-router";

interface Todos {
    id: number;
    todoTitle: string;
    todoDescription: string;
    todoCompleted: string;
}

type RouteParams = {
    id:string;
}
const CompletedTodos:React.FC<{}> =() =>{

    const nav=useNavigate();

    const{id} = useParams<RouteParams>();

    const[title,setTitle]= useState("");
    const[description,setDescription]= useState("");
    const[completed, setCompleted] = useState("Yes");

    const fetchData = async () => {
        const response = await axios.get<Todos>("http://localhost:8040/api/todosLists/"+id);
        setTitle(response.data[`todoTitle`]);
        setDescription(response.data[`todoDescription`]);
        
    }

    useEffect(() => {
        fetchData();
    },[]);

    const sendData = async () => {
        const newDepartment ={
            "id" : id,
            "todoTitle":title,
            "todoDescription":description,
            "todoCompleted":completed
        };
        await axios.put("http://localhost:8040/api/todosLists/"+id,newDepartment);
        alert("added");
        nav("/");
    }
    
        return(
            <>
               <Container>
                <Button variant="success" style={{textAlign:"center"}} onClick={sendData}>click to add</Button>
               </Container>
            </>
        )
    }
        
export default CompletedTodos;
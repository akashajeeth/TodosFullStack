import axios from "axios";
import React, { Component, useEffect, useState } from "react";
import { Col, Container, Row, Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import './ListTodos.css';

interface Todos {
    id: number;
    todoTitle: string;
    todoDescription: string;
    todoCompleted: string;
}


const ListTodos: React.FC = () => {

    const [todosList, setTodosList] = useState<Todos[]>([]);

    const fetchData = async () => {
        const response = await axios.get<Todos[]>("http://localhost:8040/api/todosLists");
        setTodosList(response.data);
        console.log(response.data);
    }

    useEffect(() => {
        fetchData();
    }, [])

    return (
        <>
            <div className="header">
                <h4>Todos Management Applications</h4>
            </div>
            <Container>
                <Row>
                    
                    <Col md={12}>
                        <div className="heading1">
                        <h1>Todos List Component</h1>
                        </div>
                    </Col>

                    <Col md={12}>
                        <Link className="btn btn-primary" to={`/todosadd/`}>Add Todo</Link>
                    </Col>
                    <Col md={12}>
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Completed</th>
                                    <th>Actions</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    todosList.map(temp => (
                                        <tr key={temp.id}>
                                            <td>{temp.todoTitle}</td>
                                            <td>{temp.todoDescription}</td>
                                            <td>{temp.todoCompleted}</td>
                                            <td>
                                                <Link className="btn btn-info" to={`/todosupdate/${temp.id}`}> Update </Link>                                  
                                                <Link className="btn btn-danger" to={`/todosdelete/${temp.id}`}> Delete </Link>
                                                <Link className="btn btn-success" to={`/todoscomplete/${temp.id}`}> Completed </Link>
                                                <Link className="btn btn-warning" to={`/todosincomplete/${temp.id}`}> Incompleted </Link>

                                            </td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </Table>
                    </Col>
                </Row>
            </Container>
            <div className="footer">
                <h4>@Copyrights reserved</h4>
            </div>

        </>
    );
};

export default ListTodos;
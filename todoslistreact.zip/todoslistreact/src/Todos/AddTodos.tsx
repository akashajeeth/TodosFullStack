import React, { Component, useState } from "react";
import axios from "axios";
import { Alert, Button, Col, Container, Form, Row } from "react-bootstrap";
import { useNavigate } from "react-router";
import './AddTodos.css';

const AddTodos: React.FC = () => {

    const nav=useNavigate();

    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    
    const sendData = async () => {
        const newDepartment = {
            "id": 0,
            "todoTitle": title,
            "todoDescription": description,
            "todoCompleted" : " "
        };
        await axios.post("http://localhost:8040/api/todosLists", newDepartment);
    }
    const goback=()=>{
        nav("/")
    }

    return (
        <>
        <body>
            <Container>
                <Row>
                    <Col md={12}>
                        <h1>Todos Add</h1>
                    </Col>
                    
                    <Col md={12}>
                        <Form>
                            <Form.Group className="mb-3">
                                <Form.Label>Title</Form.Label>
                                <Form.Control type="text" onChange={(e) => setTitle(e.target.value)} />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Label>Description</Form.Label>
                                <Form.Control type="text" onChange={(e) => setDescription(e.target.value)} />
                            </Form.Group>
                            
                            <Button variant="primary" type="submit" onClick={sendData}>
                                Submit
                            </Button>
                            <Button style={{marginLeft:"10px"}} variant="primary" type="submit" onClick={goback}>Back</Button>
                        </Form>
                    </Col>
                </Row>
            </Container>
            </body>
        </>
    )

};

export default AddTodos;
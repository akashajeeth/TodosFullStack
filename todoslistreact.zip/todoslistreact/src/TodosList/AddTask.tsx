import axios from "axios";
import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";


const AddTask: React.FC<{}> = () => {

  const [todoTitle, settodoTitle] = useState("");
  const [todoDescription, settodoDescription] = useState("");
  const [todoCompleted, settodoCompleted] = useState("");

  const nav = useNavigate();
  const Addtask = async () => {

    const todo = {
      "todoTitle": todoTitle,
      "todoDescription": todoDescription,
      "todoCompleted": todoCompleted

    }

    const response = await axios.post(
      "http://localhost:8040/api/todosLists", todo);
    alert("new task added");
    nav('/');

  };


  return (

    <>
      <Form>
        <h3 className="updatetitle">Add Task</h3>
        <Form.Group className="mb-3" controlId="formBasicName">
          <Form.Label>Todo Title</Form.Label>
          <Form.Control type="text" onChange={(e) => settodoTitle(e.target.value)} />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicName">
          <Form.Label>Todo Description</Form.Label>
          <Form.Control type="text" onChange={(e) => settodoDescription(e.target.value)} />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicName">
          <Form.Label>Todo Completed</Form.Label>
          <Form.Select onChange={(e) => settodoCompleted(e.target.value)}>
            <option value="">Select...</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </Form.Select>
        </Form.Group>

        <Button variant="primary" type="button" onClick={Addtask} >
          Yes
        </Button>{" "}
        <Button variant="primary" type="button" href={`/`}>
          No
        </Button>
      </Form>

    </>
  )
}

export default AddTask;
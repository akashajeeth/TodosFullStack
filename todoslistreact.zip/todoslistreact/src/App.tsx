import React, { Suspense } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import AddTodos from './Todos/AddTodos';
import UpdateTodos from './Todos/UpdateTodos';
import ListTodos from './Todos/ListTodos';
import DeleteTodos from './Todos/DeleteTodos';
import { Button, Card, Container, Nav, Navbar } from 'react-bootstrap';
import CompletedTodos from './Todos/CompletedTodos';
import InCompletedTodos from './Todos/InCompleted';
import HomeTodoList from './TodosList/HomeTodoList';
import AddTask from './TodosList/AddTask';
import DeleteTask from './TodosList/DeleteTask';
import UpdateTask from './TodosList/UpdateTask';

function App() {
  return (
    <>

      {/* <BrowserRouter basename='/'>
        <Suspense fallback={<div>Loading...</div>}>
          <Routes>
            <Route index element={<ListTodos />} />
            <Route path='/todosadd' element={<AddTodos />} />
            <Route path='/todosupdate/:id' element={<UpdateTodos />} />
            <Route path='/todosdelete/:id' element={<DeleteTodos />} />
            <Route path='/todoscomplete/:id' element={<CompletedTodos />} />
            <Route path='/todosincomplete/:id' element={<InCompletedTodos />} />
          </Routes>
        </Suspense>
      </BrowserRouter> */}
      <BrowserRouter basename='/'>
        <Routes>
        <Route path='/' element={<HomeTodoList></HomeTodoList>}></Route>
        <Route path='/addtask' element={<AddTask></AddTask>}></Route>
        <Route path='/updatetask/:id' element={<UpdateTask></UpdateTask>}></Route>
        <Route path='/deletetask/:id' element={<DeleteTask></DeleteTask>}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
